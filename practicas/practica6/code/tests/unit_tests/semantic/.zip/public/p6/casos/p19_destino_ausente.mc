ausente = true + 1;
