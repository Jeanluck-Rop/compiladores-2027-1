int x = 10 + 5 + 2;
