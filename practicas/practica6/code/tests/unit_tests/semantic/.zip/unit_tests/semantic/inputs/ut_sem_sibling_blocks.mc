{
    int a;
    a = 1;
}
{
    int a;
    a = 2;
}
