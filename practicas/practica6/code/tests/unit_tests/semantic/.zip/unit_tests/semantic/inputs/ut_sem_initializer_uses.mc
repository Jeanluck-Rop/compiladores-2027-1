int a = 1;
int b = a + c;
int d = d;
