x = 10;
int x;
