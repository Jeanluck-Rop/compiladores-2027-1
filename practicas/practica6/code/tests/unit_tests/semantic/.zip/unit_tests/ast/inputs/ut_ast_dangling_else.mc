int x = 10;

if (x > 0)
    if (x > 5)
        print(1);
    else
        print(2);
